﻿using Microsoft.AspNetCore.Mvc;
using ApiCitasMedicas.Facades;
using ApiCitasMedicas.Models;

namespace ApiCitasMedicas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicosController : ControllerBase
    {
        private readonly CitasFacade _citasFacade;

        public MedicosController(CitasFacade citasFacade)
        {
            _citasFacade = citasFacade;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Medico>>> GetMedicos()
        {
            return await _citasFacade.ObtenerMedicos();
        }

        [HttpPost]
        public async Task<ActionResult<Medico>> CreateMedico(Medico medico)
        {
            var nuevoMedico = await _citasFacade.AgregarMedico(medico);
            return CreatedAtAction(nameof(GetMedicos), new { id = nuevoMedico.Id }, nuevoMedico);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMedico(int id, Medico medico)
        {
            var resultado = await _citasFacade.ActualizarMedico(id, medico);
            if (!resultado) return BadRequest();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMedico(int id)
        {
            var resultado = await _citasFacade.EliminarMedico(id);
            if (!resultado) return NotFound();
            return NoContent();
        }
    }
}
