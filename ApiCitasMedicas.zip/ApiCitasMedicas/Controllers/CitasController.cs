﻿using Microsoft.AspNetCore.Mvc;
using ApiCitasMedicas.Facades;
using ApiCitasMedicas.Models;

namespace ApiCitasMedicas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CitasController : ControllerBase
    {
        private readonly CitasFacade _citasFacade;

        public CitasController(CitasFacade citasFacade)
        {
            _citasFacade = citasFacade;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cita>>> GetCitas()
        {
            return await _citasFacade.ObtenerCitas();
        }

        [HttpPost]
        public async Task<ActionResult<Cita>> CreateCita(Cita cita)
        {
            var nuevaCita = await _citasFacade.AgregarCita(cita);
            return CreatedAtAction(nameof(GetCitas), new { id = nuevaCita.Id }, nuevaCita);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCita(int id, Cita cita)
        {
            var resultado = await _citasFacade.ActualizarCita(id, cita);
            if (!resultado) return BadRequest();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCita(int id)
        {
            var resultado = await _citasFacade.EliminarCita(id);
            if (!resultado) return NotFound();
            return NoContent();
        }
    }
}
