﻿using Microsoft.AspNetCore.Mvc;
using ApiCitasMedicas.Facades;
using ApiCitasMedicas.Models;

namespace ApiCitasMedicas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PacientesController : ControllerBase
    {
        private readonly CitasFacade _citasFacade;

        public PacientesController(CitasFacade citasFacade)
        {
            _citasFacade = citasFacade;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Paciente>>> GetPacientes()
        {
            return await _citasFacade.ObtenerPacientes();
        }

        [HttpPost]
        public async Task<ActionResult<Paciente>> CreatePaciente(Paciente paciente)
        {
            var nuevoPaciente = await _citasFacade.AgregarPaciente(paciente);
            return CreatedAtAction(nameof(GetPacientes), new { id = nuevoPaciente.Id }, nuevoPaciente);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePaciente(int id, Paciente paciente)
        {
            var resultado = await _citasFacade.ActualizarPaciente(id, paciente);
            if (!resultado) return BadRequest();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePaciente(int id)
        {
            var resultado = await _citasFacade.EliminarPaciente(id);
            if (!resultado) return NotFound();
            return NoContent();
        }
    }
}
